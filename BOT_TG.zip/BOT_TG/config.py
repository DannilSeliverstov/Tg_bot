TOKEN = '6947858334:AAHyvC9vk7SFiynWuninWsM9U0DmwK9zKdk'

keys = {
    'Евро': 'EUR',
    'Доллар': 'USD',
    'Рубль': 'RUB',
}